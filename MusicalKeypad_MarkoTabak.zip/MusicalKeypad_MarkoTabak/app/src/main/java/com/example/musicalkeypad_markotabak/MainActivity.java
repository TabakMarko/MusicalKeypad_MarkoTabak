package com.example.musicalkeypad_markotabak;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private SoundPool soundPool;
    private int[] soundIds;
    private Button[] buttons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        soundPool = new SoundPool(6, AudioManager.STREAM_MUSIC, 0);

        soundIds = new int[] {
                soundPool.load(this, R.raw.piano_c, 1),
                soundPool.load(this, R.raw.piano_d, 1),
                soundPool.load(this, R.raw.piano_e, 1),
                soundPool.load(this, R.raw.piano_f, 1),
                soundPool.load(this, R.raw.piano_g, 1),
                soundPool.load(this, R.raw.piano_a, 1),
                soundPool.load(this, R.raw.piano_h, 1),
                soundPool.load(this, R.raw.piano_b, 1)
        };

        buttons = new Button[] {
                findViewById(R.id.button_c),
                findViewById(R.id.button_d),
                findViewById(R.id.button_e),
                findViewById(R.id.button_f),
                findViewById(R.id.button_g),
                findViewById(R.id.button_a),
                findViewById(R.id.button_h),
                findViewById(R.id.button_b)
        };
        for (Button button : buttons) {
            button.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_c:
                soundPool.play(soundIds[0], 1, 1, 0, 0, 1);
                break;
            case R.id.button_d:
                soundPool.play(soundIds[1], 1, 1, 0, 0, 1);
                break;
            case R.id.button_e:
                soundPool.play(soundIds[2], 1, 1, 0, 0, 1);
                break;
            case R.id.button_f:
                soundPool.play(soundIds[3], 1, 1, 0, 0, 1);
                break;
            case R.id.button_g:
                soundPool.play(soundIds[4], 1, 1, 0, 0, 1);
                break;
            case R.id.button_a:
                soundPool.play(soundIds[5], 1, 1, 0, 0, 1);
                break;
            case R.id.button_h:
                soundPool.play(soundIds[6], 1, 1, 0, 0, 1);
                break;
            case R.id.button_b:
                soundPool.play(soundIds[7], 1, 1, 0, 0, 1);
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        soundPool.release();
    }
}
